import { useState } from 'react'
import reactLogo from './assets/react.svg'
import viteLogo from '/vite.svg'
import './App.css'
import Home from './components/Home'

import About from './components/About'
import { BrowserRouter, Route, Routes } from 'react-router-dom'
import Master from './layout/Master'
import AdminMaster from './layout/AdminMaster'
import Dashboard from './components/Admin/Dashboard'
import ManageCustomers from './components/Admin/ManageCustomers'
import Login from './components/Login'

function App() {
 
  return (
    <>
    <BrowserRouter>
        <Routes>
            <Route path='/' element={<Login/>}>
              {/* outlets */}
                  <Route path='/Login' element={<Login/>}></Route>
                  <Route path='/' element={<Home/>}></Route>
                  <Route path='/about' element={<About/>}></Route>
                 
            </Route>
            <Route path='/admin' element={<AdminMaster/>}>
                   {/* oulets of admin */}
                    <Route path='/admin' element={<Dashboard/>}></Route>
                    <Route path='/admin/managecustomers' element={<ManageCustomers/>}></Route>
            </Route>
            
        </Routes>  
    </BrowserRouter>
     
       
        </>
  )
}

export default App
