import { useState } from "react"
import { useNavigate } from "react-router-dom";

export default function Login(){
    var[Email,setEmail]=useState("");
    var[Password,setPassword]=useState("");
    var[Gender,setGender]=useState("");
    var[State,setState]=useState("");
    var nav = useNavigate();
    function changeEmail(e){
        console.log("email is changed",e.target.value);
        setEmail(e.target.value)
        
    }
    function handleForm(e){
        // Loading stop
        e.preventDefault();
        console.log("form is submit");
        if(Email == "simran@gmail.com" && Password == 123){
            console.log("Simran user");
            alert("Login successfull")
            setTimeout(() => {
                nav("/admin")
            }, 2000);

            
        }
        else{
            console.log("user invalid");
            
        }
        
    }
    return(
        <>
  {/* Page Header End */}
  <div className="container-xxl py-5 page-header position-relative mb-5">
    <div className="container py-5">
      <h1 className="display-2 text-white animated slideInDown mb-4">
       Login   
      
       {/* {Password} */}
      </h1>
      <nav aria-label="breadcrumb animated slideInDown">
        <ol className="breadcrumb">
          <li className="breadcrumb-item">
            <a href="#">Home</a>
          </li>
          <li className="breadcrumb-item">
            <a href="#">Pages</a>
          </li>
          <li className="breadcrumb-item text-white active" aria-current="page">
           Login
          </li>
        </ol>
      </nav>
    </div>
  </div>
  {/* Page Header End */}
         {/* Appointment Start */}
         <div className="container-xxl py-5">
          <div className="container">
            <div className="bg-light rounded">
              <div className="row g-0">
                <div className="col-lg-6 wow fadeIn" data-wow-delay="0.1s">
                  <div className="h-100 d-flex flex-column justify-content-center p-5">
                    {/* <h1 className="mb-4">Make Appointment</h1> */}
                    <form onSubmit={handleForm}>
                      <div className="row g-3">
                        <div className="col-sm-12">
                          <div className="form-floating">
                            <input
                              type="email"
                              className="form-control border-0"
                              id="gname"
                              placeholder="Email"
                              value={Email}
                              onChange={changeEmail}
                            />
                            <label htmlFor="gname">Email</label>
                          </div>
                        </div>
                
                        <div className="col-sm-12">
                          <div className="form-floating">
                            <input
                              type="password"
                              className="form-control border-0"
                              id="cname"
                              placeholder="Password"
                              value={Password}
                              onChange={(e)=>{setPassword(e.target.value)}}
                            />
                            <label htmlFor="cname">Password</label>
                          </div>
                        </div>
                        <div className="col-sm-12">
                          <div className="form-floating">
                            <input
                              type="text"
                              className="form-control border-0"
                              id="cname"
                              placeholder="Gender"
                              value={Gender}
                              onChange={(e)=>{setGender(e.target.value)}}
                            />
                            <label htmlFor="cname">Gender</label>
                          </div>
                        </div>
                        <div className="col-sm-12">
                          <div className="form-floating">
                            <input
                              type="text"
                              className="form-control border-0"
                              id="cname"
                              placeholder="State"
                              value={State}
                              onChange={(e)=>{setState(e.target.value)}}
                            />
                            <label htmlFor="cname">Gender</label>
                          </div>
                        </div>


                        <div className="col-12">
                          <button
                            className="btn btn-primary w-100 py-3"
                            type="submit"
                          >
                            Submit
                          </button>
                        </div>
                      </div>
                    </form>
                  </div>
                </div>
                <div
                  className="col-lg-6 wow fadeIn"
                  data-wow-delay="0.5s"
                  style={{ minHeight: 400 }}
                >
                  <div className="position-relative h-100 pt-5">
                    {/* <img
                      className="position-absolute w-100 h-100 rounded"
                      src="/assets/img/appointment.jpg"
                      style={{ objectFit: "cover" }}
                    /> */}
                    <>
                    <h2></h2>
                    <h2> Email: {Email}</h2>
                    <h2>Password: {Password}</h2>
                    <h2>Gender: {Gender}</h2>
                    <h2>State: {State}</h2>
                    </>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </div>
        {/* Appointment End */}
 
</>

    )
}