import { useState } from "react"

export default function Dashboard(){
    var[count,setCount]=useState(0);
    function incFun(){
        console.log("fun call");
        setCount(count+1)
        
    }
  function decFun(){
    console.log("dec fun call");
    setCount(count-1)
    
  }
    return(
        <>
  {/* Page Header End */}
  <div className="container-xxl py-5 page-header position-relative mb-5">
    <div className="container py-5">
      <h1 className="display-2 text-white animated slideInDown mb-4">
       Dashboard
      </h1>
      <nav aria-label="breadcrumb animated slideInDown">
        <ol className="breadcrumb">
          <li className="breadcrumb-item">
            <a href="#">Home</a>
          </li>
          <li className="breadcrumb-item">
            <a href="#">Pages</a>
          </li>
          <li className="breadcrumb-item text-white active" aria-current="page">
           Dashboard
          </li>
        </ol>
      </nav>
    </div>
  </div>
  {/* Page Header End */}
  {/* About Start */}
  <div className="container-xxl py-5">
    <div className="container">
      <div className="row g-5 align-items-center">
                <div className="offset-md-4 col-md-5">

                    {count==0?<><h1>Hello</h1><h2>Hii</h2></>:<h1>Bye</h1>}
                    <h1>Count  {count}</h1>
                    <button onClick={incFun}>+++</button>
                    <button onClick={decFun}>----</button>
                </div>
      </div>
    </div>
  </div>
  {/* About End */}
 
</>

    )
}